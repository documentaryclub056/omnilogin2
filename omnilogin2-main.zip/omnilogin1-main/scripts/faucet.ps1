# ============================================================
#  "Faucet" - FULL automation loop for 2 OmniLogin profiles:
#
#    opens both profiles SIDE BY SIDE (half screen each)
#    -> opens each faucet website
#    -> AUTO clicks the CAPTCHA button
#    -> YOU solve the captcha
#    -> AUTO clicks the CLAIM button (as soon as it appears)
#    -> waits the site timer (default 5 min)
#    -> REPEATS forever
#
#  Roles:  captcha button = AUTO | solving = YOU | claim = AUTO
#  When you come back, the captcha is already open on screen.
#
#  Stop: close this window, or create  C:\Omni\faucet\stop.txt
# ============================================================
. "$PSScriptRoot\common.ps1"

$ErrorActionPreference = "Continue"

# ---------------- config (written by the workflow) ----------------
$cfg = @{
  PROFILE1 = ""; URL1 = ""; PROFILE2 = ""; URL2 = ""
  WAIT_MIN  = 5
  CAPTCHA_BTN = "(?i)captcha"
  CLAIM_BTN   = "(?i)claim"
}
if (Test-Path "C:\Omni\faucet\faucet.txt") {
  Get-Content "C:\Omni\faucet\faucet.txt" | ForEach-Object {
    if ($_ -match "^\s*([A-Z0-9_]+)\s*=\s*(.*)$") { $cfg[$matches[1]] = $matches[2].Trim() }
  }
}
$waitMin = 5
[int]::TryParse($cfg.WAIT_MIN, [ref]$waitMin) | Out-Null
$waitSec = $waitMin * 60
$stopFile = "C:\Omni\faucet\stop.txt"

Write-Host ""
Write-Host "=== FAUCET AUTOMATION ==="
Write-Host "Profile 1 : $($cfg.PROFILE1)   ->  $($cfg.URL1)"
Write-Host "Profile 2 : $($cfg.PROFILE2)   ->  $($cfg.URL2)"
Write-Host "Timer     : $($waitMin) min between claims"
Write-Host "Roles     : captcha-click = AUTO | solve = YOU | claim = AUTO"
Write-Host "Stop      : close this window  OR  create  $stopFile"
Write-Host ""

if (-not $cfg.PROFILE1 -or -not $cfg.URL1 -or -not $cfg.PROFILE2 -or -not $cfg.URL2) {
  Write-Host "Config is missing! Edit the FAUCET block in .github/workflows/main.yml,"
  Write-Host "make sure both profiles exist in OmniLogin, re-run the workflow, then run Faucet again."
  Read-Host "Press Enter to close"; exit 1
}

function Check-Stop {
  if (Test-Path $stopFile) { return $true }
  return $false
}

# ---------------- web page element helpers ----------------
# Clickable element types that Chromium exposes in the UIA tree
$clickTypes = @(
  [System.Windows.Automation.ControlType]::Button,
  [System.Windows.Automation.ControlType]::Link,
  [System.Windows.Automation.ControlType]::Text,
  [System.Windows.Automation.ControlType]::Image,
  [System.Windows.Automation.ControlType]::Custom,
  [System.Windows.Automation.ControlType]::Group
)

function Find-PageElement {
  param($Win, [string]$Pattern)
  try {
    $all = $Win.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                        [System.Windows.Automation.Condition]::TrueCondition)
    $cands = @($all | Where-Object {
        ($_.Current.Name -and ($_.Current.Name -match $Pattern)) -and
        ($clickTypes -contains $_.Current.ControlType)
      })
    foreach ($c in $cands) { if ($c.Current.IsEnabled) { return $c } }
    if ($cands.Count -gt 0) { return $cands[0] }
  } catch {}
  return $null
}

function Click-Element {
  param($El)
  if (-not $El) { return $false }
  try {
    $ip = $El.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    if ($ip) { $ip.Invoke(); return $true }
  } catch {}
  # fallback: real mouse click on the element's center (works on web pages)
  try {
    $r = $El.Current.BoundingRectangle
    [Win32.User32]::SetCursorPos([int]($r.X + $r.Width / 2), [int]($r.Y + $r.Height / 2))
    Start-Sleep -Milliseconds 120
    [Win32.User32]::mouse_event(0x0002, 0, 0, 0, [System.UIntPtr]::Zero)  # left down
    [Win32.User32]::mouse_event(0x0004, 0, 0, 0, [System.UIntPtr]::Zero)  # left up
    return $true
  } catch {}
  return $false
}

function Set-WindowRect {
  param($Win, [int]$x, [int]$y, [int]$w, [int]$h)
  try {
    $hwnd = [IntPtr]$Win.Current.NativeWindowHandle
    [Win32.User32]::SetWindowPos($hwnd, [IntPtr]0, $x, $y, $w, $h, 0x0003) | Out-Null
    Start-Sleep -Milliseconds 400
  } catch {}
}

function Focus-Window {
  param($Win)
  try {
    $hwnd = [IntPtr]$Win.Current.NativeWindowHandle
    [Win32.User32]::SetForegroundWindow($hwnd) | Out-Null
    Start-Sleep -Milliseconds 400
  } catch { try { $Win.SetFocus() } catch {} }
}

function Navigate-Url {
  param($Win, [string]$Url)
  Focus-Window $Win
  [System.Windows.Forms.SendKeys]::SendWait("^l")   # address bar (Chromium standard)
  Start-Sleep -Milliseconds 300
  [System.Windows.Forms.SendKeys]::SendWait((ConvertTo-SendKeys $Url))
  [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
}

function Reload-Window {
  param($Win)
  Focus-Window $Win
  [System.Windows.Forms.SendKeys]::SendWait("^r")
}

function Get-TopWindows {
  $root = [System.Windows.Automation.AutomationElement]::RootElement
  $all = $root.FindAll([System.Windows.Automation.TreeScope]::Children,
                       [System.Windows.Automation.Condition]::TrueCondition)
  $wins = @()
  foreach ($w in $all) {
    try {
      if ($w.Current.ControlType -ne [System.Windows.Automation.ControlType]::Window) { continue }
      if ($w.Current.Name -eq "") { continue }
      $pid2 = $w.Current.ProcessId
      $pname = ""
      try { $pname = (Get-Process -Id $pid2 -ErrorAction Stop).Name } catch {}
      if ($pname -match "^(cmd|conhost|powershell|pwsh|explorer|searchhost|dwm|RuntimeBroker|sihost)$") { continue }
      $wins += $w
    } catch {}
  }
  return $wins
}

function Wait-NewWindow {
  param([System.Windows.Automation.AutomationElement[]]$Before, [int]$Seconds = 60)
  $beforeHandles = @($Before | ForEach-Object { try { [long]$_.Current.NativeWindowHandle } catch { 0 } })
  for ($i = 0; $i -lt ($Seconds / 3); $i++) {
    Start-Sleep -Seconds 3
    foreach ($w in @(Get-TopWindows)) {
      $h = 0
      try { $h = [long]$w.Current.NativeWindowHandle } catch {}
      if ($h -ne 0 -and ($beforeHandles -notcontains $h)) { return $w }
    }
  }
  return $null
}

# ---------------- 1. start Omni + auto-login ----------------
$creds = @(Get-OmniCreds)
$email = $creds[0]; $pass = $creds[1]

$exe = Start-Omni
if (-not $exe) {
  Write-Host "OmniLogin not found - run 'Download' on the desktop first, install it, then run Faucet again."
  Read-Host "Press Enter to close"; exit 1
}

$dash = Wait-OmniWindow -Seconds 90
if (-not $dash) {
  Write-Host "OmniLogin window not found. Click the app once and re-run Faucet."
  Read-Host "Press Enter to close"; exit 1
}
Write-Host "Dashboard: $($dash.Current.Name)"
Start-Sleep -Seconds 3

$logged = $false
for ($i = 0; $i -lt 10 -and -not $logged; $i++) {
  $logged = Fill-Login $dash $email $pass
  if (-not $logged) { Start-Sleep -Seconds 2 }
}
Start-Sleep -Seconds 3

# ---------------- 2. open both profiles ----------------
function Launch-Profile {
  param($ProfileName)
  $before = @(Get-TopWindows)
  $d = Get-OmniWindow
  if ($d) {
    try {
      $all = $d.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                        [System.Windows.Automation.Condition]::TrueCondition)
      $card = @($all | Where-Object {
          ($_.Current.Name -and ($_.Current.Name -match [regex]::Escape($ProfileName)))
        } | Where-Object {
          $r = $_.Current.BoundingRectangle
          ($r.Width -gt 60 -and $r.Height -gt 40)
        }) | Select-Object -First 1
      if ($card) {
        $sub = @($card.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                               [System.Windows.Automation.Condition]::TrueCondition) |
                 Where-Object {
                   $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button -and
                   ($_.Current.Name -match "(?i)launch|open|run|start")
                 })
        if ($sub.Count -gt 0) {
          Click-Element $sub[0]
          Write-Host "  launched '$ProfileName' via button."
        } else {
          $r = $card.Current.BoundingRectangle
          [Win32.User32]::SetCursorPos([int]($r.X + $r.Width / 2), [int]($r.Y + $r.Height / 2))
          Start-Sleep -Milliseconds 100
          [Win32.User32]::mouse_event(0x0002, 0, 0, 0, [System.UIntPtr]::Zero)
          [Win32.User32]::mouse_event(0x0004, 0, 0, 0, [System.UIntPtr]::Zero)
          Start-Sleep -Milliseconds 100
          [Win32.User32]::mouse_event(0x0002, 0, 0, 0, [System.UIntPtr]::Zero)
          [Win32.User32]::mouse_event(0x0004, 0, 0, 0, [System.UIntPtr]::Zero)
          Write-Host "  double-clicked '$ProfileName' card."
        }
      } else {
        Write-Host "  could not find profile '$ProfileName' in the dashboard."
      }
    } catch { Write-Host "  dashboard click failed: $_" }
  }
  $nw = Wait-NewWindow $before -Seconds 45
  if ($nw) { Write-Host "  browser window opened: $($nw.Current.Name)" }
  return $nw
}

Write-Host "Opening profile 1: $($cfg.PROFILE1)"
$w1 = Launch-Profile $cfg.PROFILE1
if (-not $w1) {
  Write-Host "  No new window - double-click profile '$($cfg.PROFILE1)' in Omni right now, I will wait..."
  $w1 = Wait-NewWindow @(Get-TopWindows) -Seconds 90
}

Start-Sleep -Seconds 3
Write-Host "Opening profile 2: $($cfg.PROFILE2)"
$w2 = Launch-Profile $cfg.PROFILE2
if (-not $w2) {
  Write-Host "  No new window - double-click profile '$($cfg.PROFILE2)' in Omni right now, I will wait..."
  $w2 = Wait-NewWindow @(Get-TopWindows) -Seconds 90
}

# last resort: attach to already-open browser windows (non-dashboard)
if (-not $w1 -or -not $w2) {
  Write-Host "Attaching to already-open browser windows..."
  $dn = ""
  $d2 = Get-OmniWindow
  if ($d2) { $dn = $d2.Current.Name }
  $open = @(Get-TopWindows | Where-Object { $_.Current.Name -ne $dn })
  if (-not $w1) { $w1 = $open[0] }
  if (-not $w2) {
    $w2 = @($open | Where-Object { $_ -ne $w1 }) | Select-Object -First 1
  }
}

if (-not $w1 -or -not $w2) {
  Write-Host "I need 2 browser windows but only have what I found."
  Write-Host "Open BOTH profiles in OmniLogin, then re-run 'Faucet'."
  Read-Host "Press Enter to close"; exit 1
}

# ---------------- 3. split screen: half / half ----------------
$screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
$half   = [int]($screen.Width / 2)
Set-WindowRect $w1 $screen.X $screen.Y $half $screen.Height
Set-WindowRect $w2 ($screen.X + $half) $screen.Y $half $screen.Height
Write-Host "Screen split: profile 1 on the LEFT, profile 2 on the RIGHT."

# ---------------- 4. open the faucet sites ----------------
Write-Host "Opening faucet sites..."
Navigate-Url $w1 $cfg.URL1
Start-Sleep -Seconds 8
Navigate-Url $w2 $cfg.URL2
Start-Sleep -Seconds 8

# warm-up: first UIA query makes Chromium build its accessibility tree
$null = Find-PageElement $w1 "(?s).{0}"
$null = Find-PageElement $w2 "(?s).{0}"
Start-Sleep -Seconds 3

# ---------------- 5. THE LOOP ----------------
$round = 0
$running = $true
while ($running) {
  if (Check-Stop) { Write-Host "stop.txt found - stopping the loop."; $running = $false; break }
  $round++
  Write-Host ""
  Write-Host "============================================================"
  Write-Host "  ROUND $round - $(Get-Date -Format 'HH:mm:ss')"
  Write-Host "============================================================"

  # 5a. fresh reload of both sites
  Write-Host "Reloading both sites..."
  Reload-Window $w1
  Start-Sleep -Seconds 1
  Reload-Window $w2
  Start-Sleep -Seconds 8

  # 5b. AUTO: click the captcha button in both windows
  foreach ($pair in @(@{ N = $cfg.PROFILE1; W = $w1 }, @{ N = $cfg.PROFILE2; W = $w2 })) {
    $btn = $null
    for ($i = 0; $i -lt 18 -and -not $btn; $i++) {
      $btn = Find-PageElement $pair.W $cfg.CAPTCHA_BTN
      if (-not $btn) { Start-Sleep -Seconds 5 }
    }
    if ($btn) {
      if (Click-Element $btn) { Write-Host "  CAPTCHA opened  -> $($pair.N)" }
      else { Write-Host "  captcha button found but click failed -> $($pair.N)" }
    } else {
      Write-Host "  CAPTCHA button NOT found -> $($pair.N)  (check the CAPTCHA_BTN pattern in the workflow config)"
    }
  }

  # 5c. YOU solve the captchas - we watch for the CLAIM button to appear
  Write-Host ""
  Write-Host "  >>> NOW YOU SOLVE THE 2 CAPTCHAS <<<"
  Write-Host "  I click CLAIM the moment it appears. Then the $($waitMin) min timer starts."
  Write-Host ""
  $claim1 = $null
  $claim2 = $null
  $deadline = (Get-Date).AddMinutes(30)
  while ((($claim1 -eq $null) -or ($claim2 -eq $null)) -and ((Get-Date) -lt $deadline)) {
    if (Check-Stop) { $running = $false; break }
    if ($null -eq $claim1) { $claim1 = Find-PageElement $w1 $cfg.CLAIM_BTN }
    if ($null -eq $claim2) { $claim2 = Find-PageElement $w2 $cfg.CLAIM_BTN }
    Start-Sleep -Seconds 5
  }
  if (-not $running) { break }
  if (($claim1 -eq $null) -or ($claim2 -eq $null)) {
    Write-Host "  Timed out waiting for the claim button(s) after 30 min - reloading for a fresh round."
    continue
  }

  # 5d. AUTO: click CLAIM in both
  $c1 = Find-PageElement $w1 $cfg.CLAIM_BTN
  if ($c1) { if (Click-Element $c1) { Write-Host "  CLAIM clicked -> $($cfg.PROFILE1)" } else { Write-Host "  claim click FAILED -> $($cfg.PROFILE1)" } }
  $c2 = Find-PageElement $w2 $cfg.CLAIM_BTN
  if ($c2) { if (Click-Element $c2) { Write-Host "  CLAIM clicked -> $($cfg.PROFILE2)" } else { Write-Host "  claim click FAILED -> $($cfg.PROFILE2)" } }

  # 5e. wait for the site timer
  Write-Host "  Timer: $($waitMin) min - when you come back, the new captcha will already be open."
  $endTime = (Get-Date).AddSeconds($waitSec)
  while ((Get-Date) -lt $endTime) {
    if (Check-Stop) { $running = $false; break }
    $left = [int]($endTime - (Get-Date)).TotalMinutes
    if (($left % 5 -eq 0) -or ($left -le 1)) { Write-Host "  timer: $($left) min left" }
    Start-Sleep -Seconds 20
  }
}

Write-Host ""
Write-Host "Faucet loop stopped. (Ran $round round(s).)"
Write-Host ""
Read-Host "Press Enter to close"
