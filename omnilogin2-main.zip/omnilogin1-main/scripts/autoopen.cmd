@echo off
rem Opens the OmniLogin site automatically on the first RDP login
set "URL=https://www.omnilogin.net/"
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
  start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "%URL%"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
  start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "%URL%"
) else (
  start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" "%URL%"
)
