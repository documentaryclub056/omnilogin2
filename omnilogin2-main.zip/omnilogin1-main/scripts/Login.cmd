@echo off
title OmniLogin - Login
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Omni\login.ps1"
