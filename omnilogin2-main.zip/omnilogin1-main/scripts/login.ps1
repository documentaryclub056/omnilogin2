# ============================================================
#  "Login" - starts OmniLogin and logs in with your saved
#  email/password (asks once, then remembers forever).
# ============================================================
. "$PSScriptRoot\common.ps1"

Write-Host ""
Write-Host "=== OmniLogin Login ==="

$creds = @(Get-OmniCreds)
$email = $creds[0]
$pass  = $creds[1]

$exe = Start-Omni
if (-not $exe) {
  Write-Host ""
  Write-Host "OmniLogin was not found on this machine yet. To set it up:"
  Write-Host "  1. Run 'Download' on your desktop"
  Write-Host "  2. On the page click the Download button -> run the .exe installer (Next / Next / Finish)"
  Write-Host "  3. Run this 'Login' script again"
  Write-Host ""
  Read-Host "Press Enter to close"
  exit 1
}

$win = Wait-OmniWindow -Seconds 90
if (-not $win) {
  Write-Host "Could not find the OmniLogin window. Click the app once, then re-run this script."
  Read-Host "Press Enter to close"
  exit 1
}
Write-Host "Window: $($win.Current.Name)"

# the login screen may take a while to render its fields - retry until found
$ok = $false
for ($i = 0; $i -lt 15 -and -not $ok; $i++) {
  $ok = Fill-Login $win $email $pass
  if (-not $ok) { Start-Sleep -Seconds 2 }
}

if ($ok) {
  Write-Host "Credentials filled - logging in."
} else {
  Write-Host ""
  Write-Host "No login fields were detected:"
  Write-Host "  - If the login screen is open: your email is on the clipboard - paste it where asked."
  Set-Clipboard $email
  Write-Host "      Email: $email"
  Write-Host "  - If you are already logged in: nothing to do, all good."
}
Start-Sleep -Seconds 4
Write-Host ""
Write-Host "Done. If the login screen is still open, finish it manually this one time."
Write-Host ""
Read-Host "Press Enter to close"
