@echo off
title OmniLogin - Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Omni\setup.ps1"
