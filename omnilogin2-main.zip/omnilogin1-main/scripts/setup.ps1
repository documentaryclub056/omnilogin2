# ============================================================
#  "Setup" - one-click OmniLogin setup for beginners:
#   - starts Omni (and logs in first if needed, using saved creds)
#   - walks the profile wizard using the automatic options
#   - switches on "auto" settings it can find
# ============================================================
. "$PSScriptRoot\common.ps1"

Write-Host ""
Write-Host "=== OmniLogin Auto-Setup ==="
Write-Host ""

# ============ EDIT ME (optional, recommended) ============
# The automatic mode below clicks buttons by name guessing.
# For a 100% reliable setup, type the EXACT button labels you
# see inside Omni here - one per line, in the order they appear:
$ExactClicks = @(
  # "New profile",
  # "Use automatic fingerprint",
  # "Skip",
  # "Create"
)
# =========================================================

$creds = @(Get-OmniCreds)
$email = $creds[0]
$pass  = $creds[1]

$exe = Start-Omni
if (-not $exe) {
  Write-Host "OmniLogin not found. Run 'Download' on your desktop first, install it, then run 'Setup' again."
  Read-Host "Press Enter to close"
  exit 1
}

$win = Wait-OmniWindow -Seconds 90
if (-not $win) {
  Write-Host "Could not find the OmniLogin window. Click the app once, then re-run 'Setup'."
  Read-Host "Press Enter to close"
  exit 1
}
Write-Host "Window: $($win.Current.Name)"
Start-Sleep -Seconds 3

# ---- Step 1: if the login screen is open, log in automatically first ----
if (Fill-Login $win $email $pass) {
  Write-Host "Credentials filled - logging in. Giving the app a moment..."
  Start-Sleep -Seconds 5
} else {
  Write-Host "No login fields seen - assuming you are already logged in."
}

# ---- Step 2: click through the profile wizard ----
$win = Wait-WizardToFinish
if ($win) {
  if ($ExactClicks.Count -gt 0) {
    Write-Host ""
    Write-Host "Using your exact click list:"
    foreach ($label in $ExactClicks) {
      Click-ButtonMatching $win @("^" + [regex]::Escape($label) + "$")
    }
  } else {
    Write-Host ""
    Write-Host "Using automatic click detection (best effort):"
    $generic = @(
      "(?i)^(new profile|create profile|add profile)$",
      "(?i)^(new|create|add)$",
      "(?i)auto",
      "(?i)random",
      "(?i)generate",
      "(?i)^(skip)$",
      "(?i)^(next|continue|save|create|done|finish)$"
    )
    $guard = 0
    while ($guard -lt 12) {
      if (Click-ButtonMatching $win $generic) { $guard++ } else { break }
    }
  }
}

# ---- Step 3: switch on "auto" toggles that are visible ----
$win = Wait-WizardToFinish
if ($win) {
  Write-Host ""
  Write-Host "Checking 'auto' settings:"
  $n = Toggle-AutoSettings $win
  if ($n -eq 0) { Write-Host "  nothing to switch (or nothing detected)." }
}

Write-Host ""
Write-Host "Setup pass finished."
Write-Host "Open the OmniLogin window and check the profile list - a profile with an"
Write-Host "automatic fingerprint should be there, ready to launch."
Write-Host ""
Write-Host "If any step needed a manual click, tell me the exact button names and I will"
Write-Host "add them to the 'EDIT ME' list above - next time it will be 100% automatic."
Write-Host ""
Read-Host "Press Enter to close"
