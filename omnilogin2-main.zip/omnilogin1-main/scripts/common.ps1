# ============================================================
#  OmniLogin RDP - shared helpers (used by login.ps1, setup.ps1)
# ============================================================
$ErrorActionPreference = "Continue"

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms

# Win32 helpers (window positioning, real mouse clicks, focus)
if (-not ("Win32.User32" -as [type])) {
  $null = Add-Type -Namespace Win32 -Name User32 -MemberDefinition @"
[DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
[DllImport("user32.dll")] public static extern void SetCursorPos(int X, int Y);
[DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, System.UIntPtr dwExtraInfo);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
"@
}

$OmniDir  = "C:\Omni"
$CredFile = Join-Path $OmniDir "creds.txt"

# ------------------------------------------------------------
# Credentials: load from C:\Omni\creds.txt; if missing, ask
# the user once and save the answer for next time.
# Returns: @(email, password)
# ------------------------------------------------------------
function Get-OmniCreds {
  $email = ""; $pass = ""
  if (Test-Path $CredFile) {
    $lines = @(Get-Content $CredFile | Where-Object { $_.Trim() -ne "" })
    if ($lines.Count -ge 1) { $email = $lines[0].Trim() }
    if ($lines.Count -ge 2) { $pass  = $lines[1].Trim() }
  }
  if ((-not $email) -or ($email -match "PUT_") -or (-not $pass)) {
    Write-Host ""
    Write-Host "Enter your OmniLogin account (omnilogin.net) - you only type it once:"
    $email = Read-Host "  Email"
    $sec   = Read-Host "  Password" -AsSecureString
    $pass  = (New-Object System.Net.NetworkCredential("u", $sec)).Password
    Set-Content -Path $CredFile -Value @($email, $pass) -Encoding ASCII
    Write-Host "  Saved to $CredFile - next time it logs in automatically."
  }
  return @($email, $pass)
}

# ------------------------------------------------------------
# Find the OmniLogin program:
#  1) installed (Start Menu shortcuts, any "Omni" app)
#  2) common install folders
#  3) downloaded installer / portable .exe in Downloads
# ------------------------------------------------------------
function Find-OmniExe {
  $found = $null

  $ws = New-Object -ComObject WScript.Shell
  $lnkDirs = @(
    "C:\ProgramData\Microsoft\Windows\Start Menu\Programs",
    "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
  )
  foreach ($d in $lnkDirs) {
    if ($found) { break }
    Get-ChildItem $d -Recurse -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {
      if ($found) { return }
      try {
        $s = $ws.CreateShortcut($_.FullName)
        if ($s.TargetPath -and $s.TargetPath -match "(?i)omni" -and (Test-Path $s.TargetPath)) {
          $found = $s.TargetPath
        }
      } catch {}
    }
  }

  if (-not $found) {
    $paths = @(
      "$env:ProgramFiles\OmniLogin\OmniLogin.exe",
      "$env:ProgramFiles\OmniLogin\Omni.exe",
      "$env:ProgramFiles\omnilogin\omnilogin.exe",
      "${env:ProgramFiles(x86)}\OmniLogin\OmniLogin.exe",
      "$env:LOCALAPPDATA\Programs\OmniLogin\OmniLogin.exe",
      "$env:LOCALAPPDATA\Programs\Omni\OmniLogin.exe",
      "$env:LOCALAPPDATA\OmniLogin\OmniLogin.exe"
    )
    foreach ($p in $paths) { if (Test-Path $p) { $found = $p; break } }
  }

  if (-not $found) {
    $dl = Get-ChildItem "$env:USERPROFILE\Downloads" -Filter *.exe -ErrorAction SilentlyContinue |
          Where-Object { $_.Name -match "(?i)omni" } |
          Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($dl) { $found = $dl.FullName }
  }

  return $found
}

# ------------------------------------------------------------
# Start OmniLogin if it is not already running. Returns the exe path.
# ------------------------------------------------------------
function Start-Omni {
  $exe = Find-OmniExe
  if (-not $exe) { return $null }
  $proc = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "(?i)^omni" }
  if ($proc) {
    Write-Host "OmniLogin is already running."
  } else {
    Write-Host "Starting: $exe"
    Start-Process -FilePath $exe
  }
  return $exe
}

# ------------------------------------------------------------
# Find the top-level window whose title contains "Omni"
# ------------------------------------------------------------
function Get-OmniWindow {
  $root = [System.Windows.Automation.AutomationElement]::RootElement
  $wins = $root.FindAll([System.Windows.Automation.TreeScope]::Children,
                        [System.Windows.Automation.Condition]::TrueCondition)
  foreach ($w in $wins) {
    try {
      if ($w.Current.Name -match "(?i)omni") { return $w }
    } catch {}
  }
  return $null
}

function Wait-OmniWindow {
  param([int]$Seconds = 90)
  $win = $null
  $t = 0
  while ($t -lt $Seconds) {
    Start-Sleep -Seconds 2
    $t += 2
    $win = Get-OmniWindow
    if ($win) { break }
  }
  return $win
}

# Re-fetch the current Omni window after dialog changes
function Wait-WizardToFinish {
  param([int]$Tries = 5)
  for ($i = 0; $i -lt $Tries; $i++) {
    $w = Get-OmniWindow
    if ($w) { return $w }
    Start-Sleep -Seconds 2
  }
  return $null
}

# Escape characters that SendKeys treats as special (+ ^ % ~ { })
function ConvertTo-SendKeys([string]$s) {
  $map = @{ '{' = '{{}'; '}' = '{}}'; '^' = '{^}'; '%' = '{%}'; '+' = '{+}'; '~' = '{~}' }
  $out = ""
  foreach ($ch in $s.ToCharArray()) {
    $k = [string]$ch
    if ($map.ContainsKey($k)) { $out += $map[$k] } else { $out += $k }
  }
  return $out
}

# ------------------------------------------------------------
# Auto-fill login: types email into the first text box, password
# into the second, then clicks the login button (or presses Enter).
# Returns $false when no login fields were found.
# ------------------------------------------------------------
function Fill-Login {
  param($Window, [string]$Email, [string]$Password)
  $all = $Window.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                         [System.Windows.Automation.Condition]::TrueCondition)
  $edits = @($all | Where-Object { $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Edit })
  if ($edits.Count -lt 2) { return $false }

  foreach ($pair in @(@($edits[0], $Email), @($edits[1], $Password))) {
    $el = $pair[0]; $text = $pair[1]
    $ok = $false
    try {
      $vp = $el.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
      if ($vp -and -not $vp.Current.IsReadOnly) { $vp.SetValue($text); $ok = $true }
    } catch {}
    if (-not $ok) {
      try {
        $el.SetFocus()
        Start-Sleep -Milliseconds 300
        [System.Windows.Forms.SendKeys]::SendWait((ConvertTo-SendKeys $text))
        $ok = $true
      } catch {}
    }
    Start-Sleep -Milliseconds 400
  }

  $btn = @($all | Where-Object {
        $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button -and
        ($_.Current.Name -match "(?i)^(log ?in|sign ?in|continue|next|ok)$")
      }) | Select-Object -First 1
  if ($btn) {
    try {
      $ip = $btn.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
      if ($ip) { $ip.Invoke(); Write-Host "  clicked: $($btn.Current.Name)"; return $true }
    } catch {}
  }
  try { [System.Windows.Forms.SendKeys]::SendWait("{ENTER}") } catch {}
  return $true
}

# ------------------------------------------------------------
# Click the first button whose name matches any of the patterns.
# Returns $true if something was clicked.
# ------------------------------------------------------------
function Click-ButtonMatching {
  param($Window, [string[]]$Patterns)
  $all = $Window.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                         [System.Windows.Automation.Condition]::TrueCondition)
  $btns = @($all | Where-Object {
        $_.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button -and
        ($null -ne $_.Current.Name) -and ($_.Current.Name.Trim() -ne "")
      })
  foreach ($b in $btns) {
    $hit = $false
    foreach ($pat in $Patterns) {
      if ($b.Current.Name -match $pat) { $hit = $true; break }
    }
    if (-not $hit) { continue }
    try {
      $ip = $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
      if ($ip) {
        $ip.Invoke()
        Write-Host "  clicked: $($b.Current.Name)"
        Start-Sleep -Seconds 3
        return $true
      }
    } catch {}
    try {
      $b.SetFocus()
      [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
      Write-Host "  pressed: $($b.Current.Name)"
      Start-Sleep -Seconds 3
      return $true
    } catch {}
  }
  return $false
}

# ------------------------------------------------------------
# Switch ON any checkbox/toggle whose label mentions
# auto / automatic / rotation / sync. Returns how many were toggled.
# ------------------------------------------------------------
function Toggle-AutoSettings {
  param($Window)
  $count = 0
  $all = $Window.FindAll([System.Windows.Automation.TreeScope]::Descendants,
                         [System.Windows.Automation.Condition]::TrueCondition)
  foreach ($el in $all) {
    try {
      $ct = $el.Current.ControlType
      $isToggle = ($ct -eq [System.Windows.Automation.ControlType]::CheckBox)
      $named = ($el.Current.Name -match "(?i)auto|automatic|rotation|sync")
      if (-not ($isToggle -and $named)) { continue }
      $tp = $el.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
      if ($tp -and $tp.Current.ToggleState -eq [System.Windows.Automation.ToggleState]::Off) {
        $tp.Toggle()
        $count++
        Write-Host "  switched on: $($el.Current.Name)"
      }
    } catch {}
  }
  return $count
}
