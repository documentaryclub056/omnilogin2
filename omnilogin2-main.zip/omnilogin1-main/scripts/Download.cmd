@echo off
title OmniLogin - Download
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Omni\download.ps1"
