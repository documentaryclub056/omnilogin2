@echo off
title Faucet Automation
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Omni\faucet.ps1"
