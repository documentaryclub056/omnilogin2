# ============================================================
#  "Download" - opens the OmniLogin site in Chrome so you can
#  grab the Windows installer (one click on the page).
# ============================================================
$url = "https://www.omnilogin.net/"
if (Test-Path "C:\Omni\config.txt") {
  $c = (Get-Content "C:\Omni\config.txt" | Select-Object -First 1).Trim()
  if ($c) { $url = $c }
}

$chrome = @(
  "C:\Program Files\Google\Chrome\Application\chrome.exe",
  "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($chrome) {
  Start-Process -FilePath $chrome -ArgumentList $url
} else {
  Start-Process $url   # falls back to the default browser
}

Write-Host ""
Write-Host "Opened: $url"
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Click the DOWNLOAD button on the page (Windows version)"
Write-Host "  2. When the .exe is downloaded, run it: Next / Next / Finish"
Write-Host "  3. Run 'Login' on your desktop (or 'Setup' to do everything at once)"
Write-Host ""
Read-Host "Press Enter to close"
