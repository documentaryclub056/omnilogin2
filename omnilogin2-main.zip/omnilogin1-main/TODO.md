# OmniLogin RDP - To-Do List

How it works: **Actions tab -> "Run workflow"** -> your Windows RDP machine.
Log in: user `RDP` / password `Admin1.` (editable in the workflow).

## Done in this update

- [x] **1. 6-hour limit — now: clean stop at 5:30 + manual re-run (no auto-renewal)**
  - The machine **stops itself at 5h 30m** (one-line setting: `$stopAtMinutes = 330` in
    the last workflow step — change to 360 to use the full 6h).
  - Next session = **Actions tab -> Run workflow** (1 click).
  - **No more IP hunting:** every machine joins Tailscale with the same name
    `omni-rdp` (editable), so your RDP address is always
    **omni-rdp.YOUR-TAILNET.ts.net** (needs MagicDNS ON in Tailscale — on by default).
    The per-run IP is still printed in the logs if you ever want it.
  - Tip: old `omni-rdp` entries marked "not connected" in your Tailscale admin panel
    can be deleted anytime.

- [x] **2. OmniLogin opens when the RDP opens**
  - Chrome auto-opens **https://www.omnilogin.net/** on first RDP login.
  - Desktop **Download.cmd** re-opens the site any time.

- [x] **3. "Login" desktop script**
  - Detects the Omni exe (installed OR downloaded to Downloads).
  - Asks you for email + password **once** (typed into the window), saves it to
    `C:\Omni\creds.txt` — never asks again.
  - Runs the software, waits for the login screen, fills email + password and presses login.
  - You can also pre-fill it in the workflow: `LOGIN - EDIT YOUR omnilogin.net DETAILS HERE`.

- [x] **4. "Setup" desktop script** — one-click: logs in if needed, walks the profile
  wizard with automatic options (auto fingerprint, skip proxy, create), switches on
  "auto" settings.
  - [ ] Make **2 profiles** in Omni (run Setup twice, or create them manually).
  - [ ] Test on the machine — if a click is missed, send a screenshot of the Omni
    window and the exact button names get added to `EDIT ME` in `scripts/setup.ps1`.

- [x] **5. "Faucet" desktop script — FULL automation loop (new)**
  - Opens **both profiles side by side** (profile 1 left half, profile 2 right half).
  - Loads each faucet website.
  - Loop:
    1. **AUTO** clicks the captcha button (both windows)
    2. **YOU** solve the captcha
    3. **AUTO** clicks CLAIM the moment the claim button appears
    4. **AUTO** waits the 5-min timer
    5. repeat — when you come back, the new captcha is **already open** on screen
  - Config: edit the `FAUCET` block in the workflow (profile names, both site URLs,
    timer, captcha/claim button text).
  - Stop: close the Faucet window, or create `C:\Omni\faucet\stop.txt`.
  - If the profile doesn't auto-launch, it tells you to double-click it (and waits),
    or attaches to windows you already have open.
  - [ ] Test on the machine — send screenshots of the faucet page + Omni dashboard
    if the captcha/claim button pattern needs tightening.

## Notes

- Repo is **private** — credentials in the workflow file are not public. Extra-safety
  option: repo secrets (`OMNI_EMAIL` / `OMNI_PASS`) — ask me to wire those in.
- Free minutes: each 5.5h machine = 330 of your 2000 free minutes/month (~6 machines).
  Stop runs when you are not using them.
- Tailscale auth key must stay **reusable** (one-time use OFF) for the machines to join.

## OmniLogin questions — answered

- Free plan = **2 browser profiles, free forever**, automation included.
- No native MCP / AI features (checked official site + 2026 comparisons).
- Automation = no-code drag & drop + action synchronizer + free REST API.
